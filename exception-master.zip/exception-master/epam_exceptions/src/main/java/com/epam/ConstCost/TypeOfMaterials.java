package com.epam.ConstCost;

public enum TypeOfMaterials {
    standard,
    mediumStandard,
    highStandard;
}